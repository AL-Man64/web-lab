# sources

- cart.png, search.png, banner.png: pixabay
- ai.png: AI generated on canva
- category banners: bing with filters
- other pictures: created using my code, at al-man64/graphics-stuff
